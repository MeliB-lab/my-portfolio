import { useEffect } from "react";
import { motion } from "motion/react";
import { ArrowLeft, ArrowRight, Lock, Layers, MessageSquare, FolderSearch, Anchor, Lightbulb } from "lucide-react";
import { useNavigate } from "react-router";
import { CustomCursor } from "../components/CustomCursor";
import "../../styles/fonts.css";

// ─── Design system primitives ─────────────────────────────────────────────────

function FadeUp({ children, delay = 0, style }: { children: React.ReactNode; delay?: number; style?: React.CSSProperties }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] }}
      style={style}
    >
      {children}
    </motion.div>
  );
}

function SectionLabel({ num, label }: { num: string; label: string }) {
  return (
    <p style={{ fontFamily: "var(--font-mono)", fontSize: 10, letterSpacing: "0.26em", textTransform: "uppercase", color: "var(--muted-foreground)", margin: "0 0 10px" }}>
      {num} — {label}
    </p>
  );
}

function Rule() {
  return <div style={{ height: 1, background: "var(--border)", margin: "0 0 2.5rem" }} />;
}

function Callout({ children, accent = false }: { children: React.ReactNode; accent?: boolean }) {
  return (
    <FadeUp>
      <div style={{
        background: accent ? "rgba(184,104,64,0.06)" : "var(--card)",
        border: `1px solid ${accent ? "rgba(184,104,64,0.22)" : "var(--border)"}`,
        borderLeft: `3px solid ${accent ? "var(--accent)" : "var(--muted)"}`,
        borderRadius: "0 8px 8px 0",
        padding: "1.25rem 1.5rem",
        marginBottom: "1.5rem",
      }}>
        {children}
      </div>
    </FadeUp>
  );
}

// Wiggle tag component
function WiggleTag({ label, dark = false }: { label: string; dark?: boolean }) {
  return (
    <motion.span
      whileHover={{ rotate: [0, -4, 4, -2, 2, 0] }}
      transition={{ duration: 0.35, ease: "easeInOut" }}
      style={{
        display: "inline-block",
        fontFamily: "var(--font-mono)",
        fontSize: 9,
        letterSpacing: "0.1em",
        color: dark ? "rgba(244,239,230,0.80)" : "var(--muted-foreground)",
        border: `1px solid ${dark ? "rgba(244,239,230,0.32)" : "var(--border)"}`,
        borderRadius: 4,
        padding: "3px 9px",
      }}
    >
      {label}
    </motion.span>
  );
}

// Finding card with animated icon
const FINDING_ICONS = [
  { Icon: Layers, anim: { scale: [1, 1.12, 1] }, dur: 2.6 },
  { Icon: MessageSquare, anim: { y: [0, -5, 0] }, dur: 2.8 },
  { Icon: FolderSearch, anim: { rotate: [0, 8, 0, -8, 0] }, dur: 3.2 },
  { Icon: Anchor, anim: { scale: [1, 0.92, 1] }, dur: 3.0 },
];

function FindingCard({ title, body, iconIndex, delay = 0 }: { title: string; body: string; iconIndex: number; delay?: number }) {
  const { Icon, anim, dur } = FINDING_ICONS[iconIndex % FINDING_ICONS.length];
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.5, delay, ease: [0.22, 1, 0.36, 1] }}
      style={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 10, padding: "1.5rem" }}
    >
      <motion.div
        animate={anim as any}
        transition={{ duration: dur, repeat: Infinity, ease: "easeInOut" }}
        style={{ width: "fit-content", marginBottom: 14 }}
      >
        <Icon size={30} style={{ color: "var(--accent)" }} strokeWidth={1.4} />
      </motion.div>
      <p style={{ fontFamily: "var(--font-display)", fontSize: "1.05rem", color: "var(--foreground)", margin: "0 0 8px" }}>{title}</p>
      <p style={{ fontFamily: "var(--font-body)", fontSize: "0.85rem", lineHeight: 1.72, color: "var(--muted-foreground)", margin: 0 }}>{body}</p>
    </motion.div>
  );
}

function VimeoEmbed({ id, title, caption }: { id: string; title: string; caption: string }) {
  return (
    <FadeUp style={{ margin: "2.5rem 0" }}>
      <div style={{ position: "relative", paddingTop: "56.25%", borderRadius: 10, overflow: "hidden", background: "var(--card)" }}>
        <iframe
          src={`https://player.vimeo.com/video/${id}?badge=0&autopause=0&player_id=0`}
          style={{ position: "absolute", top: 0, left: 0, width: "100%", height: "100%", border: "none" }}
          allow="autoplay; fullscreen; picture-in-picture"
          allowFullScreen
          title={title}
        />
      </div>
      <p style={{ fontFamily: "var(--font-mono)", fontSize: 10, letterSpacing: "0.1em", color: "var(--muted-foreground)", margin: "10px 0 0", textAlign: "center" }}>{caption}</p>
    </FadeUp>
  );
}

function NDANotice() {
  return (
    <FadeUp style={{ marginBottom: "3rem" }}>
      <div style={{ display: "flex", gap: 14, background: "rgba(42,24,16,0.04)", border: "1px solid var(--border)", borderRadius: 8, padding: "1.1rem 1.4rem" }}>
        <Lock size={16} style={{ color: "var(--muted-foreground)", flexShrink: 0, marginTop: 2 }} />
        <div>
          <p style={{ fontFamily: "var(--font-mono)", fontSize: 9, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--muted-foreground)", margin: "0 0 4px" }}>NDA Protected</p>
          <p style={{ fontFamily: "var(--font-body)", fontSize: "0.83rem", lineHeight: 1.65, color: "var(--muted-foreground)", margin: 0 }}>
            Completed under a client NDA. Screens, terminology, and implementation details have been simplified or omitted. Process, design decisions, and lessons learned accurately reflect my contributions.
          </p>
        </div>
      </div>
    </FadeUp>
  );
}

// Illustration for "What I Learned" — animated concentric rings + icon
function LearningIllustration() {
  return (
    <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: 130, position: "relative", margin: "1.5rem 0 2rem" }}>
      <motion.div style={{ width: 110, height: 110, borderRadius: "50%", border: "1px solid rgba(184,104,64,0.15)", position: "absolute" }} animate={{ scale: [1, 1.07, 1] }} transition={{ duration: 4.5, repeat: Infinity, ease: "easeInOut" }} />
      <motion.div style={{ width: 76, height: 76, borderRadius: "50%", border: "1.5px solid rgba(184,104,64,0.25)", position: "absolute" }} animate={{ scale: [1, 1.1, 1] }} transition={{ duration: 3.8, repeat: Infinity, ease: "easeInOut", delay: 0.4 }} />
      <motion.div style={{ width: 48, height: 48, borderRadius: "50%", background: "rgba(184,104,64,0.08)", border: "1px solid rgba(184,104,64,0.3)", position: "absolute", display: "flex", alignItems: "center", justifyContent: "center" }} animate={{ scale: [1, 1.06, 1] }} transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: 0.7 }}>
        <Lightbulb size={20} style={{ color: "var(--accent)" }} strokeWidth={1.4} />
      </motion.div>
      {[[-34, -26], [36, -22], [-28, 32], [32, 30]].map(([x, y], i) => (
        <motion.div key={i} style={{ width: i % 2 === 0 ? 6 : 4, height: i % 2 === 0 ? 6 : 4, borderRadius: "50%", background: "var(--accent)", opacity: 0.45, position: "absolute", left: `calc(50% + ${x}px)`, top: `calc(50% + ${y}px)` }} animate={{ y: [0, -7, 0], opacity: [0.35, 0.75, 0.35] }} transition={{ duration: 2.5 + i * 0.5, repeat: Infinity, ease: "easeInOut", delay: i * 0.35 }} />
      ))}
    </div>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────

export function UnifiedExperiencePage() {
  const navigate = useNavigate();
  useEffect(() => { window.scrollTo(0, 0); }, []);

  return (
    <div style={{ background: "var(--background)", fontFamily: "var(--font-body)", minHeight: "100vh" }}>
      <CustomCursor />

      {/* Sticky top nav */}
      <div style={{ position: "sticky", top: 0, zIndex: 50, background: "rgba(250,246,238,0.90)", backdropFilter: "blur(14px)", borderBottom: "1px solid var(--border)", padding: "14px clamp(1.5rem, 5vw, 4rem)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <motion.button
          onClick={() => navigate("/")}
          whileHover={{ x: -3 }}
          transition={{ type: "spring", stiffness: 400, damping: 25 }}
          style={{ display: "flex", alignItems: "center", gap: 8, fontFamily: "var(--font-mono)", fontSize: 11, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--muted-foreground)", background: "none", border: "none", cursor: "none", transition: "color 0.2s" }}
          onMouseEnter={(e) => (e.currentTarget.style.color = "var(--accent)")}
          onMouseLeave={(e) => (e.currentTarget.style.color = "var(--muted-foreground)")}
        >
          <ArrowLeft size={14} /> Portfolio
        </motion.button>
        <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--muted-foreground)" }}>Case Study · 02</span>
      </div>

      {/* Hero */}
      <div style={{ background: "#2A1810", padding: "5rem clamp(1.5rem, 5vw, 4rem) 4rem" }}>
        <div style={{ maxWidth: 860, margin: "0 auto" }}>
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: "1.5rem" }}
          >
            {["Grant Management", "Legacy Modernization", "Govtech", "508 Accessible"].map(t => (
              <WiggleTag key={t} label={t} dark />
            ))}
          </motion.div>
          <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.1 }} style={{ fontFamily: "var(--font-display)", fontSize: "clamp(2rem, 5vw, 3.8rem)", lineHeight: 1.1, color: "#F0E8DC", margin: "0 0 1.25rem", fontWeight: 400 }}>
            Bringing Disconnected Grant Workflows Into One Experience
          </motion.h1>
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3, duration: 0.6 }} style={{ fontFamily: "var(--font-body)", fontSize: "1.05rem", lineHeight: 1.72, color: "rgba(244,239,230,0.65)", maxWidth: 600, margin: 0 }}>
            Modernizing a legacy grant management platform by bringing fragmented workflows, communication, and application management into a unified experience.
          </motion.p>
        </div>
      </div>

      {/* Meta grid */}
      <div style={{ background: "var(--secondary)", borderBottom: "1px solid var(--border)" }}>
        <div style={{ maxWidth: 860, margin: "0 auto", padding: "3rem clamp(1.5rem, 5vw, 4rem)" }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: "2.5rem 3rem" }}>
            {[
              { label: "Role", value: "UX Research · UX/UI Design · Workflow Design · Technical Feasibility Reviews" },
              { label: "Timeline", value: "2022 – 2025" },
              { label: "Team", value: "Sahar Zavaree · Melissa Cerritos · Brham Persaud" },
              { label: "Organization", value: "GrantSolutions" },
            ].map(item => (
              <div key={item.label}>
                <p style={{ fontFamily: "var(--font-mono)", fontSize: 9, letterSpacing: "0.22em", textTransform: "uppercase", color: "var(--muted-foreground)", margin: "0 0 8px" }}>{item.label}</p>
                <p style={{ fontFamily: "var(--font-body)", fontSize: "0.9rem", lineHeight: 1.65, color: "var(--foreground)", margin: 0 }}>{item.value}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <div style={{ maxWidth: 860, margin: "0 auto", padding: "4rem clamp(1.5rem, 5vw, 4rem)" }}>

        <NDANotice />

        {/* What I Owned */}
        <FadeUp><SectionLabel num="01" label="What I Owned" /></FadeUp>
        <Rule />
        <FadeUp>
          <p style={{ fontFamily: "var(--font-body)", fontSize: "0.95rem", lineHeight: 1.8, color: "var(--muted-foreground)", marginBottom: "1.25rem" }}>
            Unified Experience was a collaborative effort. My contributions focused on <strong style={{ color: "var(--foreground)", fontWeight: 500 }}>discovery and early design phases</strong> — user interviews, research synthesis, workflow design, and UX/UI for the Grants List and Grant Messages experiences. The project later transitioned to Scrum delivery teams for implementation.
          </p>
        </FadeUp>
        <Callout accent>
          <p style={{ fontFamily: "var(--font-mono)", fontSize: 9, letterSpacing: "0.16em", textTransform: "uppercase", color: "var(--accent)", margin: "0 0 6px" }}>Note on scope</p>
          <p style={{ fontFamily: "var(--font-body)", fontSize: "0.85rem", lineHeight: 1.7, color: "var(--foreground)", margin: 0 }}>
            While not every design detail remained unchanged through implementation, the research findings, workflows, and initial designs documented here reflect my direct contributions.
          </p>
        </Callout>

        {/* The Challenge */}
        <FadeUp style={{ marginTop: "3rem" }}><SectionLabel num="02" label="The Challenge" /></FadeUp>
        <Rule />
        <FadeUp>
          <p style={{ fontFamily: "var(--font-body)", fontSize: "0.95rem", lineHeight: 1.8, color: "var(--muted-foreground)", marginBottom: "1.25rem" }}>
            Grant specialists managed applications, communications, and documentation across multiple disconnected areas of the platform. Many users had spent years in the legacy experience. Any modernization effort needed to improve efficiency <em>without disrupting the workflows users relied on daily.</em>
          </p>
          <p style={{ fontFamily: "var(--font-body)", fontSize: "0.95rem", lineHeight: 1.8, color: "var(--muted-foreground)", marginBottom: "3rem" }}>
            The challenge wasn't simply redesigning screens — it was helping users transition without breaking the habits that made them effective.
          </p>
        </FadeUp>

        {/* Understanding Users */}
        <FadeUp><SectionLabel num="03" label="Understanding Users" /></FadeUp>
        <Rule />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "1rem", marginBottom: "3rem" }}>
          {[
            { method: "User Interviews", note: "5 sessions · common + super users · questions focused on workarounds, daily workflows, and audit preparation" },
            { method: "Observation", note: "We observed users move between systems, where they lost time, and where existing workflows created friction" },
            { method: "Synthesis", note: "Affinity mapping, current-state workflow mapping, gap analysis, and internal stakeholder reviews" },
          ].map((m, i) => (
            <FadeUp key={m.method} delay={i * 0.08}>
              <div style={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 8, padding: "1.1rem 1.25rem", height: "100%" }}>
                <p style={{ fontFamily: "var(--font-mono)", fontSize: 9, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--accent)", margin: "0 0 8px" }}>{m.method}</p>
                <p style={{ fontFamily: "var(--font-body)", fontSize: "0.83rem", lineHeight: 1.65, color: "var(--muted-foreground)", margin: 0 }}>{m.note}</p>
              </div>
            </FadeUp>
          ))}
        </div>

        {/* Key Findings */}
        <FadeUp><SectionLabel num="04" label="Key Findings" /></FadeUp>
        <Rule />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "1rem", marginBottom: "3rem" }}>
          <FindingCard iconIndex={0} delay={0.00} title="Information Was Scattered" body="Users frequently moved between multiple areas to complete a single task — no single source of truth existed." />
          <FindingCard iconIndex={1} delay={0.08} title="Communication Lacked Context" body="Important conversations happened outside the system, making project history nearly impossible to track." />
          <FindingCard iconIndex={2} delay={0.16} title="File Retrieval Was Time-Consuming" body="Attachments existed in multiple locations, creating confusion and difficulty during audits." />
          <FindingCard iconIndex={3} delay={0.24} title="Users Needed Stability" body="Long-time users relied on established workflows and expected predictable, familiar behavior." />
        </div>

        {/* Designing the Transition */}
        <FadeUp><SectionLabel num="05" label="Designing the Transition" /></FadeUp>
        <Rule />
        <Callout accent>
          <p style={{ fontFamily: "var(--font-display)", fontStyle: "italic", fontSize: "1.1rem", color: "var(--foreground)", margin: "0 0 10px" }}>
            "When analytics showed users defaulting to Classic, I proposed connecting the two experiences — making it effortless to move between Classic and the Unified experience in the parts that were built, rather than forcing a switch."
          </p>
          <p style={{ fontFamily: "var(--font-body)", fontSize: "0.83rem", color: "var(--muted-foreground)", margin: 0 }}>
            I looked at how Yahoo handled their own product migration — giving users time to adjust while gently promoting the new experience — and brought that framing to our internal stakeholders. The goal wasn't compliance, it was confidence. The proposal was approved and shaped how we designed the Classic-to-Unified handoff.
          </p>
        </Callout>
        <FadeUp>
          <p style={{ fontFamily: "var(--font-body)", fontSize: "0.95rem", lineHeight: 1.8, color: "var(--muted-foreground)", marginBottom: "3rem" }}>
            Users had years of muscle memory. Design decisions focused on preserving recognizable patterns while simplifying navigation and reducing unnecessary steps — giving users an on-ramp to the new experience on their own terms.
          </p>
        </FadeUp>

        {/* Grants List */}
        <FadeUp><SectionLabel num="06" label="Grants List" /></FadeUp>
        <Rule />
        <FadeUp>
          <p style={{ fontFamily: "var(--font-body)", fontSize: "0.95rem", lineHeight: 1.8, color: "var(--muted-foreground)", marginBottom: "1.25rem" }}>
            Grant information existed across multiple screens. Users reported concerns about missing updates and difficulty locating what they needed to perform their work efficiently.
          </p>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.6rem 1.5rem", marginBottom: "1.5rem" }}>
            {[
              "Centralized application hub combining previously scattered information",
              "Quick and advanced filters built directly into the workflow",
              "Clearer status visibility and application history",
              "Classic / Unified toggle — a respectful transition path",
              "Improved saved search — easy to locate, save, and retrieve",
              "Key grant health points surfaced at a glance with quick action access",
            ].map((d, i) => (
              <div key={i} style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                <span style={{ width: 5, height: 5, borderRadius: "50%", background: "var(--accent)", flexShrink: 0, marginTop: 8 }} />
                <p style={{ fontFamily: "var(--font-body)", fontSize: "0.85rem", lineHeight: 1.65, color: "var(--muted-foreground)", margin: 0 }}>{d}</p>
              </div>
            ))}
          </div>
        </FadeUp>
        <VimeoEmbed id="717590765" title="Grants List Demo" caption="Grants List — Vimeo demo (publicly available)" />

        {/* Grant Messages */}
        <FadeUp><SectionLabel num="07" label="Grant Messages" /></FadeUp>
        <Rule />
        <FadeUp>
          <p style={{ fontFamily: "var(--font-body)", fontSize: "0.95rem", lineHeight: 1.8, color: "var(--muted-foreground)", marginBottom: "1.25rem" }}>
            Communication history was fragmented and often happened outside the platform. Attachments were distributed across multiple locations, making retrieval difficult.
          </p>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.6rem 1.5rem", marginBottom: "1.5rem" }}>
            {[
              "Centralized experience for viewing and managing conversations",
              "Attachment indicators directly within message threads",
              "Bulk messaging workflow for high-volume communication",
              "Notification strategy for individual and async processes",
            ].map((d, i) => (
              <div key={i} style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                <span style={{ width: 5, height: 5, borderRadius: "50%", background: "#4A7A52", flexShrink: 0, marginTop: 8 }} />
                <p style={{ fontFamily: "var(--font-body)", fontSize: "0.85rem", lineHeight: 1.65, color: "var(--muted-foreground)", margin: 0 }}>{d}</p>
              </div>
            ))}
          </div>
        </FadeUp>
        <VimeoEmbed id="717602059" title="Grant Messages Demo" caption="Grant Messages — Vimeo demo (publicly available)" />

        {/* Handoff */}
        <FadeUp><SectionLabel num="08" label="Handoff & Evolution" /></FadeUp>
        <Rule />
        <FadeUp>
          <p style={{ fontFamily: "var(--font-body)", fontSize: "0.95rem", lineHeight: 1.8, color: "var(--muted-foreground)", marginBottom: "3rem" }}>
            Following discovery, workflow design, and technical feasibility reviews, the project transitioned into Scrum delivery teams. My involvement concluded after the initial design phase. As the product moved through delivery, some experiences evolved while others were simplified to accommodate technical constraints. The overall research and design foundation informed the final experience.
          </p>
        </FadeUp>

        {/* What I Learned */}
        <FadeUp><SectionLabel num="09" label="What I Learned" /></FadeUp>
        <Rule />
        <LearningIllustration />
        <Callout accent>
          <p style={{ fontFamily: "var(--font-display)", fontStyle: "italic", fontSize: "1.15rem", lineHeight: 1.4, color: "var(--foreground)", margin: "0 0 12px" }}>
            "Technical feasibility isn't simply asking whether something can be built. It's understanding whether the teams implementing it have the time, context, and shared understanding to deliver it successfully."
          </p>
          <p style={{ fontFamily: "var(--font-body)", fontSize: "0.88rem", lineHeight: 1.72, color: "var(--muted-foreground)", margin: 0 }}>
            This experience changed how I approach collaboration. I now advocate for involving implementation teams earlier in the design process, creating opportunities for alignment long before development begins.
          </p>
        </Callout>
      </div>

      {/* Footer nav */}
      <div style={{ borderTop: "1px solid var(--border)", padding: "2.5rem clamp(1.5rem, 5vw, 4rem)", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "1rem", background: "var(--secondary)" }}>
        <motion.button
          onClick={() => navigate("/")}
          whileHover={{ x: -3 }}
          transition={{ type: "spring", stiffness: 400, damping: 25 }}
          style={{ display: "flex", alignItems: "center", gap: 8, fontFamily: "var(--font-mono)", fontSize: 11, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--muted-foreground)", background: "none", border: "none", cursor: "none", transition: "color 0.2s" }}
          onMouseEnter={(e) => (e.currentTarget.style.color = "var(--foreground)")}
          onMouseLeave={(e) => (e.currentTarget.style.color = "var(--muted-foreground)")}
        >
          <ArrowLeft size={14} /> Back to Portfolio
        </motion.button>
        <motion.button
          onClick={() => navigate("/work/usda-ams")}
          whileHover={{ x: 3 }}
          transition={{ type: "spring", stiffness: 400, damping: 25 }}
          style={{ display: "flex", alignItems: "center", gap: 8, fontFamily: "var(--font-mono)", fontSize: 11, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--muted-foreground)", background: "none", border: "none", cursor: "none", transition: "color 0.2s" }}
          onMouseEnter={(e) => (e.currentTarget.style.color = "var(--foreground)")}
          onMouseLeave={(e) => (e.currentTarget.style.color = "var(--muted-foreground)")}
        >
          Next: USDA PPR <ArrowRight size={14} />
        </motion.button>
      </div>
    </div>
  );
}
