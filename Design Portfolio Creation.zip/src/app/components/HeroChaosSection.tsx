import { useRef, useState, useEffect, useMemo, useCallback } from "react";
import {
  motion,
  useScroll,
  useTransform,
  useSpring,
  useMotionValue,
  useMotionValueEvent,
  MotionValue,
} from "motion/react";

const LABELS = [
  "Research Findings", "User Feedback", "Journey Maps", "Accessibility",
  "Business Goals", "Analytics", "Wireframes", "Design System",
  "Stakeholder Input", "Requirements", "Prototype", "Testing Results",
  "Content Strategy", "Information Architecture", "Interaction Design",
  "User Flows", "AI Agents", "Usability Insights",
];

const NOTE_COLORS = [
  { bg: "#F5D9C8", strip: "#DFB8A0", text: "#2A1810" },
  { bg: "#EDE7DA", strip: "#D5CABC", text: "#2A1810" },
  { bg: "#C8DABC", strip: "#AECA9A", text: "#1A3018" },
  { bg: "#D4C0A0", strip: "#BEA882", text: "#2A1810" },
  { bg: "#F0E8DC", strip: "#DAD0C0", text: "#2A1810" },
  { bg: "#D8CAAA", strip: "#C0AE88", text: "#2A1810" },
  { bg: "#E8C8A8", strip: "#D4AE88", text: "#2A1810" },
];

const CARD_W = 128;
const CARD_H = 88;
const REPEL_RADIUS = 140;
const MAX_FORCE = 100;

function pseudoRand(seed: number): number {
  const x = Math.sin(seed + 1) * 43758.5453123;
  return x - Math.floor(x);
}

interface CardConfig {
  id: number;
  label: string;
  initialX: number;
  initialY: number;
  initialRotate: number;
  gridX: number;
  gridY: number;
  docX: number;
  docY: number;
  colorIndex: number;
  zBase: number;
}

function generateCards(count: number, vw: number, vh: number): CardConfig[] {
  const GRID_COLS = vw > 1100 ? 5 : 4;
  const GRID_COL_W = (vw * 0.46) / GRID_COLS;
  const GRID_ROW_H = CARD_H + 8;
  const TOTAL_ROWS = Math.ceil(count / GRID_COLS);
  const GRID_Y_START = Math.max(80, (vh - TOTAL_ROWS * GRID_ROW_H) / 2);
  const DOC_COLS = 4;
  const DOC_ROW_H = 5;
  const DOC_TOTAL_ROWS = Math.ceil(count / DOC_COLS);
  const DOC_CX = vw * 0.22;
  const DOC_CY = vh * 0.46;

  return Array.from({ length: count }, (_, i) => {
    const rx = pseudoRand(i * 3.71 + 1.13);
    const ry = pseudoRand(i * 2.19 + 5.37);
    const rr = pseudoRand(i * 4.83 + 2.71);
    const rc = Math.floor(pseudoRand(i * 1.37 + 8.09) * NOTE_COLORS.length);
    const col = i % GRID_COLS;
    const row = Math.floor(i / GRID_COLS);
    const dCol = i % DOC_COLS;
    const dRow = Math.floor(i / DOC_COLS);

    return {
      id: i,
      label: LABELS[i % LABELS.length],
      initialX: rx * (vw - CARD_W),
      initialY: ry * (vh - CARD_H),
      initialRotate: rr * 30 - 15,
      gridX: 20 + col * GRID_COL_W + (GRID_COL_W - CARD_W) / 2,
      gridY: GRID_Y_START + row * GRID_ROW_H,
      docX: DOC_CX - (DOC_COLS * 11) / 2 + dCol * 11,
      docY: DOC_CY - (DOC_TOTAL_ROWS * DOC_ROW_H) / 2 + dRow * DOC_ROW_H,
      colorIndex: rc,
      zBase: Math.floor(pseudoRand(i * 0.93 + 4.1) * 10) + 1,
    };
  });
}

// ─── Pencil SVG ───────────────────────────────────────────────────────────────

function PencilTip() {
  return (
    <svg width="42" height="16" viewBox="0 0 42 16" fill="none">
      <rect x="0" y="4" width="5" height="8" rx="1.5" fill="#F5D9C8" />
      <rect x="4.2" y="4" width="1.2" height="8" fill="#D8CABB" />
      <rect x="5" y="3" width="23" height="10" rx="1" fill="#2A1810" />
      <rect x="6" y="4" width="20" height="2" rx="0.5" fill="rgba(255,255,255,0.06)" />
      <path d="M 28 3 L 40 8 L 28 13 Z" fill="#C4A882" />
      <path d="M 37 6.5 L 42 8 L 37 9.5 Z" fill="#5A5050" />
    </svg>
  );
}

// ─── Sticky Card ──────────────────────────────────────────────────────────────

function StickyCard({
  config, scrollProgress, mouseX, mouseY,
}: {
  config: CardConfig;
  scrollProgress: MotionValue<number>;
  mouseX: MotionValue<number>;
  mouseY: MotionValue<number>;
}) {
  // Stagger: each card starts its journey slightly later
  const STAGGER = config.id * 0.0018;
  const ARRIVE_END = Math.min(STAGGER + 0.54, 0.65);

  // Scroll-driven raw positions
  const rawScrollX = useTransform(scrollProgress, [STAGGER, ARRIVE_END, 0.82], [config.initialX, config.gridX, config.docX]);
  const rawScrollY = useTransform(scrollProgress, [STAGGER, ARRIVE_END, 0.82], [config.initialY, config.gridY, config.docY]);

  // Spring adds organic trailing feel — makes desktop feel as fluid as mobile
  const scrollX = useSpring(rawScrollX, { stiffness: 72, damping: 22, restDelta: 0.5 });
  const scrollY = useSpring(rawScrollY, { stiffness: 72, damping: 22, restDelta: 0.5 });

  const rotate  = useTransform(scrollProgress, [STAGGER, Math.min(ARRIVE_END, 0.46)], [config.initialRotate, 0]);
  const scale   = useTransform(scrollProgress, [0.66, 0.82], [1, 0.10]);
  const opacity = useTransform(scrollProgress, [0.76, 0.87], [1, 0]);

  // Repel springs
  const repelXBase = useMotionValue(0);
  const repelYBase = useMotionValue(0);
  const repelX = useSpring(repelXBase, { stiffness: 300, damping: 28, restDelta: 0.01 });
  const repelY = useSpring(repelYBase, { stiffness: 300, damping: 28, restDelta: 0.01 });

  // Final = scroll (with spring) + repel
  const finalX = useTransform([scrollX, repelX] as MotionValue[], ([sx, rx]: number[]) => sx + rx);
  const finalY = useTransform([scrollY, repelY] as MotionValue[], ([sy, ry]: number[]) => sy + ry);

  const computeRepel = useCallback(() => {
    const mx = mouseX.get(); const my = mouseY.get();
    const cx = rawScrollX.get() + CARD_W / 2;
    const cy = rawScrollY.get() + CARD_H / 2;
    const dx = cx - mx; const dy = cy - my;
    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist < REPEL_RADIUS && dist > 1) {
      const force = (1 - dist / REPEL_RADIUS) * MAX_FORCE;
      const angle = Math.atan2(dy, dx);
      repelXBase.set(Math.cos(angle) * force);
      repelYBase.set(Math.sin(angle) * force);
    } else {
      repelXBase.set(0);
      repelYBase.set(0);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useMotionValueEvent(mouseX, "change", computeRepel);
  useMotionValueEvent(mouseY, "change", computeRepel);

  const note = NOTE_COLORS[config.colorIndex];
  const floatY   = config.id % 2 === 0 ? 5 : -5;
  const floatRot  = ((config.id % 3) - 1) * 0.8;
  const floatDur  = 3.2 + (config.id % 5) * 0.7;
  const floatDelay = (config.id * 0.19) % 3.2;

  return (
    <motion.div
      style={{
        position: "absolute", left: 0, top: 0,
        x: finalX, y: finalY, rotate, scale, opacity,
        width: CARD_W, zIndex: config.zBase,
        willChange: "transform, opacity", pointerEvents: "none",
        filter: "drop-shadow(2px 4px 10px rgba(42,24,16,0.15)) drop-shadow(0 1px 3px rgba(42,24,16,0.09))",
      }}
    >
      <motion.div
        animate={{ y: [0, floatY, 0, floatY * -0.6, 0], rotate: [0, floatRot, 0, floatRot * -0.7, 0] }}
        transition={{ duration: floatDur, repeat: Infinity, delay: floatDelay, ease: "easeInOut" }}
      >
        <div style={{ height: 9, background: note.strip, borderRadius: "3px 3px 0 0" }} />
        <div style={{ background: note.bg, borderRadius: "0 0 3px 3px", padding: "8px 10px 10px", minHeight: CARD_H - 9 }}>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, lineHeight: 1.55, color: note.text, letterSpacing: "0.04em", wordBreak: "break-word", whiteSpace: "normal", display: "block" }}>
            {config.label}
          </span>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ─── Hero Section ─────────────────────────────────────────────────────────────

export function HeroChaosSection({ id }: { id: string }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const sectionRef   = useRef<HTMLDivElement>(null);
  const [vw, setVw] = useState(1440);
  const [vh, setVh] = useState(900);

  useEffect(() => {
    const update = () => { setVw(window.innerWidth); setVh(window.innerHeight); };
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, []);

  const cardCount = vw > 1024 ? 40 : vw > 768 ? 22 : 12;
  const cards = useMemo(() => generateCards(cardCount, vw, vh), [cardCount, vw, vh]);

  // 360vh gives 260vh of animation room — more breathing space than 280vh (180vh)
  const { scrollYProgress } = useScroll({ target: containerRef, offset: ["start start", "end end"] });

  const mouseX = useMotionValue(-9999);
  const mouseY = useMotionValue(-9999);

  const handleMouseMove = useCallback((e: React.PointerEvent) => {
    const rect = sectionRef.current?.getBoundingClientRect();
    if (!rect) return;
    mouseX.set(e.clientX - rect.left);
    mouseY.set(e.clientY - rect.top);
  }, [mouseX, mouseY]);

  const handleMouseLeave = useCallback(() => {
    mouseX.set(-9999); mouseY.set(-9999);
  }, [mouseX, mouseY]);

  // Name box + mobile name: fade as cards compress and clarity appears
  const nameOpacity   = useTransform(scrollYProgress, [0.72, 0.84], [1, 0]);
  const nameY         = useTransform(scrollYProgress, [0.72, 0.84], [0, 18]);
  // Mobile name fades earlier (phone screens need it gone before clarity text)
  const mobileNameOp  = useTransform(scrollYProgress, [0.65, 0.78], [1, 0]);

  // Pencil: draws slowly across, synchronised to card dissolution
  const strokeProgress = useTransform(scrollYProgress, [0.77, 0.89], [0, 1]);
  const strokeFade     = useTransform(scrollYProgress, [0.87, 0.93], [1, 0]);
  const pencilProgress = useTransform(scrollYProgress, [0.77, 0.89], [0, 1]);
  const pencilX = useTransform(pencilProgress, (t) => t * (window.innerWidth + 64) - 44);
  const pencilY = useTransform(pencilProgress, (t) => window.innerHeight / 2 - 8 + Math.sin(t * Math.PI * 3.5) * 6);
  const pencilFade = useTransform(scrollYProgress, [0.76, 0.785, 0.89, 0.93], [0, 1, 1, 0]);

  // Quote clip-path reveals after pencil passes — text follows the stroke
  const cl1Clip = useTransform(scrollYProgress, [0.84, 0.93], ["inset(0 100% -60px 0)", "inset(0 0% -60px 0)"]);
  const cl1Op   = useTransform(scrollYProgress, [0.84, 0.88], [0, 1]);
  const cl1Y    = useTransform(scrollYProgress, [0.84, 0.93], [12, 0]);

  const cl2Clip = useTransform(scrollYProgress, [0.89, 0.96], ["inset(0 100% -60px 0)", "inset(0 0% -60px 0)"]);
  const cl2Op   = useTransform(scrollYProgress, [0.89, 0.93], [0, 1]);
  const cl2Y    = useTransform(scrollYProgress, [0.89, 0.96], [12, 0]);

  const attrOpacity = useTransform(scrollYProgress, [0.95, 0.99], [0, 1]);
  const attrY       = useTransform(scrollYProgress, [0.95, 0.99], [18, 0]);

  // Pencil path: gently wavy horizontal line at vertical center
  const pencilPathD = `M 0,${vh / 2} C ${vw * 0.18},${vh / 2 - 7} ${vw * 0.36},${vh / 2 + 9} ${vw * 0.54},${vh / 2 - 5} C ${vw * 0.70},${vh / 2 + 8} ${vw * 0.84},${vh / 2 - 9} ${vw},${vh / 2 + 2}`;

  return (
    // 360vh: 260vh of animation room vs 180vh before — more fluid on desktop
    <div ref={containerRef} id={id} style={{ height: "360vh", position: "relative" }}>
      <div
        ref={sectionRef}
        onPointerMove={handleMouseMove}
        onPointerLeave={handleMouseLeave}
        style={{ position: "sticky", top: 0, height: "100vh", overflow: "hidden", background: "var(--background)" }}
      >
        {/* Noise */}
        <div style={{ position: "absolute", inset: 0, pointerEvents: "none", backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.78' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='300' height='300' filter='url(%23n)' opacity='0.026'/%3E%3C/svg%3E")` }} />

        {/* Top bar */}
        <motion.div
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3, duration: 0.6 }}
          style={{ position: "absolute", top: 0, left: 0, right: 0, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "28px 56px 0", zIndex: 60, pointerEvents: "none" }}
        >
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, letterSpacing: "0.22em", textTransform: "uppercase", color: "var(--muted-foreground)" }}>
            Portfolio · 2025
          </span>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <motion.span animate={{ opacity: [1, 0.25, 1] }} transition={{ duration: 2.8, repeat: Infinity }} style={{ width: 6, height: 6, borderRadius: "50%", background: "#4A7A52", display: "inline-block" }} />
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, letterSpacing: "0.1em", color: "#4A7A52" }}>Open for passion projects</span>
          </div>
        </motion.div>

        {/* Sticky notes */}
        {cards.map((card) => (
          <StickyCard key={card.id} config={card} scrollProgress={scrollYProgress} mouseX={mouseX} mouseY={mouseY} />
        ))}

        {/* Name + CTA — left (z:50) */}
        <motion.div
          style={{
            position: "absolute", left: 56, top: "50%",
            transform: "translateY(-50%)",
            zIndex: 50, opacity: nameOpacity, y: nameY,
          }}
          className="hidden md:block" // mobile: hide, handled in quote section instead
        >
          <div style={{ background: "rgba(250,246,238,0.78)", backdropFilter: "blur(18px)", WebkitBackdropFilter: "blur(18px)", borderRadius: 12, padding: "26px 30px 28px", border: "1px solid rgba(42,24,16,0.08)", boxShadow: "0 4px 24px rgba(42,24,16,0.06)", minWidth: 260 }}>
            <motion.h1
              initial={{ opacity: 0, y: 10, filter: "blur(6px)" }} animate={{ opacity: 1, y: 0, filter: "blur(0px)" }} transition={{ delay: 0.5, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
              style={{ fontFamily: "var(--font-display)", fontSize: "clamp(1.5rem, 3vw, 2.6rem)", lineHeight: 1.1, color: "var(--foreground)", margin: "0 0 10px", fontWeight: 400, letterSpacing: "-0.02em" }}
            >
              Melissa Bisyir
            </motion.h1>
            <motion.p
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.9, duration: 0.6 }}
              style={{ fontFamily: "var(--font-mono)", fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase", color: "var(--muted-foreground)", margin: "0 0 20px" }}
            >
              Senior Product Designer
            </motion.p>
            <motion.button
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.2, duration: 0.6 }}
              onClick={() => document.getElementById("work")?.scrollIntoView({ behavior: "smooth" })}
              style={{ border: "1px solid var(--border)", background: "transparent", color: "var(--muted-foreground)", fontFamily: "var(--font-mono)", fontSize: 11, letterSpacing: "0.16em", textTransform: "uppercase", padding: "9px 20px", borderRadius: 6, transition: "border-color 0.2s, color 0.2s, background 0.2s", width: "100%" }}
              onMouseEnter={(e) => { e.currentTarget.style.borderColor = "var(--accent)"; e.currentTarget.style.color = "var(--accent-foreground)"; e.currentTarget.style.background = "var(--accent)"; }}
              onMouseLeave={(e) => { e.currentTarget.style.borderColor = "var(--border)"; e.currentTarget.style.color = "var(--muted-foreground)"; e.currentTarget.style.background = "transparent"; }}
            >
              See my Work
            </motion.button>
          </div>
        </motion.div>

        {/* Mobile name block — fades before clarity text appears on phones */}
        <motion.div
          className="flex md:hidden flex-col"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.7 }}
          style={{ position: "absolute", top: 80, left: 24, right: 24, zIndex: 50, opacity: mobileNameOp }}
        >
          <h1 style={{ fontFamily: "var(--font-display)", fontSize: "clamp(2rem, 8vw, 3rem)", color: "var(--foreground)", margin: "0 0 6px", fontWeight: 400, letterSpacing: "-0.02em" }}>
            Melissa Bisyir
          </h1>
          <p style={{ fontFamily: "var(--font-mono)", fontSize: 10, letterSpacing: "0.2em", textTransform: "uppercase", color: "var(--muted-foreground)", margin: "0 0 16px" }}>
            Senior Product Designer
          </p>
          <button
            onClick={() => document.getElementById("work")?.scrollIntoView({ behavior: "smooth" })}
            style={{ border: "1px solid var(--border)", background: "transparent", color: "var(--muted-foreground)", fontFamily: "var(--font-mono)", fontSize: 10, letterSpacing: "0.14em", textTransform: "uppercase", padding: "8px 16px", borderRadius: 6, width: "fit-content" }}
          >
            See my Work
          </button>
        </motion.div>

        {/* Pencil stroke SVG (z:52) */}
        <motion.svg
          style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none", zIndex: 52, opacity: strokeFade }}
          viewBox={`0 0 ${vw} ${vh}`}
          preserveAspectRatio="none"
        >
          <motion.path d={pencilPathD} stroke="rgba(42,24,16,0.07)" strokeWidth="5" fill="none" strokeLinecap="round" style={{ pathLength: strokeProgress }} />
          <motion.path d={pencilPathD} stroke="rgba(42,24,16,0.20)" strokeWidth="1.8" fill="none" strokeLinecap="round" style={{ pathLength: strokeProgress }} />
        </motion.svg>

        {/* Pencil tip (z:53) */}
        <motion.div
          style={{ position: "absolute", left: 0, top: 0, x: pencilX, y: pencilY, opacity: pencilFade, zIndex: 53, pointerEvents: "none", rotate: -10, transformOrigin: "right center" }}
          className="hidden md:block"
        >
          <PencilTip />
        </motion.div>

        {/* Quote text — reveals in pencil's wake (z:55) */}
        <div style={{ position: "absolute", inset: 0, zIndex: 55, pointerEvents: "none", display: "flex", flexDirection: "column", justifyContent: "center", padding: "80px clamp(24px, 5vw, 56px)", overflow: "visible" }}>
          <motion.p
            style={{
              fontFamily: "var(--font-display)", fontStyle: "italic",
              fontSize: "clamp(2rem, 5.2vw, 5rem)", lineHeight: 1.08,
              color: "var(--foreground)", margin: 0,
              wordBreak: "break-word", overflowWrap: "break-word",
              clipPath: cl1Clip, opacity: cl1Op, y: cl1Y,
            }}
          >
            Clarity isn't found.
          </motion.p>
          <motion.p
            style={{
              fontFamily: "var(--font-display)",
              fontSize: "clamp(2rem, 5.2vw, 5rem)", lineHeight: 1.08,
              color: "var(--accent)", margin: "0 0 28px",
              wordBreak: "break-word",
              clipPath: cl2Clip, opacity: cl2Op, y: cl2Y,
            }}
          >
            It's created.
          </motion.p>
          <motion.div style={{ opacity: attrOpacity, y: attrY, display: "flex", flexDirection: "column", gap: 5, borderTop: "1px solid var(--border)", paddingTop: 18, maxWidth: 380 }}>
            <p style={{ fontFamily: "var(--font-display)", fontSize: "clamp(0.9rem, 2vw, 1.1rem)", color: "var(--foreground)", margin: 0 }}>
              — Melissa Bisyir
            </p>
            <p style={{ fontFamily: "var(--font-mono)", fontSize: 10, letterSpacing: "0.22em", textTransform: "uppercase", color: "var(--muted-foreground)", margin: 0 }}>
              Senior Product Designer
            </p>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6, duration: 0.7 }}
          style={{ position: "absolute", bottom: 36, left: "clamp(24px, 5vw, 56px)", zIndex: 60, display: "flex", flexDirection: "column", alignItems: "flex-start", gap: 10, pointerEvents: "none" }}
        >
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, letterSpacing: "0.24em", textTransform: "uppercase", color: "var(--muted-foreground)", opacity: 0.55 }}>
            Scroll
          </span>
          <motion.div animate={{ y: [0, 10, 0] }} transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" style={{ color: "var(--muted-foreground)", opacity: 0.5, display: "block" }}>
              <line x1="12" y1="4" x2="12" y2="20" />
              <polyline points="18 14 12 20 6 14" />
            </svg>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
